//
//  ViewController.swift
//  Rock–paper–scissors
//
//  Created by Macbook on 10/3/18.
//  Copyright © 2018 Macbook invitafo. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var comLabel: UILabel!
    @IBOutlet weak var status: UILabel!
    
    @IBOutlet weak var RB: UIButton!
    @IBOutlet weak var PB: UIButton!
    @IBOutlet weak var SB: UIButton!
    @IBOutlet weak var TryB: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        reset()
    }
    
    
   

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func reset(){
        comLabel.text = "💁🏻‍♀️"
        status.text = "R,P,S?"
        RB.isHidden = false
        RB.isEnabled = true
        PB.isHidden = false
        PB.isEnabled = true
        SB.isHidden = false
        SB.isEnabled = true
        TryB.isHidden = true
        
        
    }

    @IBAction func TrySelect(_ sender: Any) {
        
        
    }
    @IBAction func RockSelect(_ sender: Any) {
        
        
    }
    
    @IBAction func PaperSelect(_ sender: Any) {
        
        
    }
    @IBAction func ScissorsSelect(_ sender: Any) {
        
        
    }
    
    
    
}


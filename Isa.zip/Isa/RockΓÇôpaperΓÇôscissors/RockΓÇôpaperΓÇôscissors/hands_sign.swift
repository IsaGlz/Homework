//
//  hands_sign.swift
//  Rock–paper–scissors
//
//  Created by Macbook on 10/3/18.
//  Copyright © 2018 Macbook invitafo. All rights reserved.
//

import Foundation
import  GameplayKit

let RandomChoice = GKRandomDistribution(lowestValue: 0, highestValue: 1)
func RandomSign() -> Sign {
    let sign = RandomChoice.nextInt()
    if sign == 0 {
        return .rock
    } else if sign == 1 {
        return .paper
    } else {
        return .scissors
    }
}


enum Sign {
    case rock, paper, scissors
    
    var hand: String {
        switch self {
        case .rock:
            return "👊🏼"
            case .paper:
            return  "🖐🏼"
        case .scissors:
            return "✌🏼"
        }
    }
    
    func Turn(_ opponent: Sign) -> Game {
        
        switch self {
        case .rock:
              switch opponent {
              case .rock:
                return Game.draw
              case.paper:
                return Game.lose
              case .scissors:
                return Game.win
        }
            
            
        case .paper:
            switch opponent {
            case .rock:
                return Game.win
            case.paper:
                return Game.draw
            case .scissors:
                return Game.lose
            
            }
        case .scissors:
                switch opponent {
                case .rock:
                    return Game.lose
                case.paper:
                    return Game.win
                case .scissors:
                    return Game.draw
                    }
        }
   
    }
}

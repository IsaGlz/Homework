//
//  Game.swift
//  Rock–paper–scissors
//
//  Created by Macbook on 10/3/18.
//  Copyright © 2018 Macbook invitafo. All rights reserved.
//

import Foundation

enum Game {
    case win, lose, start, draw
}


//
//  ViewController.swift
//  ExamenP1
//
//  Created by Macbook on 29/10/18.
//  Copyright © 2018 iosLabIsabel. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    
   

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

   /* @IBAction func botonEnviar(){
        if  switch1==true, switch2==true{
            performSegue(withIdentifier: "vistaValita", sender: nil)
        }else{
            performSegue(withIdentifier: "vistaNovalida", sender: nil)
        }
    }*/
    
}


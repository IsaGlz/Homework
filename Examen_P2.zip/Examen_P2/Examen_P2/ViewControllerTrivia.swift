//
//  ViewControllerTrivia.swift
//  ExamenP1
//
//  Created by Macbook on 30/10/18.
//  Copyright © 2018 iosLabIsabel. All rights reserved.
//

import UIKit

class ViewControllerTrivia: UIViewController {

    @IBAction func Enviar(_ sender: Any) {
        
         if  S1.isOn==true, S2.isOn==false, S3.isOn==true, S4.isOn==false, S5.isOn==true {
         performSegue(withIdentifier: "Felicidades", sender: nil)
         }else{
         performSegue(withIdentifier: "Error", sender: nil)
         }
        
    }
    @IBOutlet weak var S5: UISwitch!
    @IBOutlet weak var S4: UISwitch!
    @IBOutlet weak var S3: UISwitch!
    @IBOutlet weak var S2: UISwitch!
    @IBOutlet weak var S1: UISwitch!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
